// This file can be replaced during build by using the `fileReplacements` array.
// `ng build` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: false,
  /**
   * Endereço da API usado por todos os services e pelo interceptor do token.
   * Para testar com a API rodando na sua máquina, troque por 'http://localhost:8080'.
   */
  apiUrl: 'https://schoolsync-api-kvfx.onrender.com',
  /** Endereço da versão web, usado no link de convite das salas. */
  webUrl: 'https://ppschoolsync.netlify.app'
};

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/plugins/zone-error';  // Included with Angular CLI.
