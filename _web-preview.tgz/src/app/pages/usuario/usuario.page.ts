import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import {
  IonContent, IonHeader, IonTitle, IonToolbar,
  IonButtons, IonBackButton, IonItem, IonInput,
  IonButton, IonIcon,
} from '@ionic/angular/standalone';
import { addIcons } from 'ionicons';
import { eyeOutline, eyeOffOutline } from 'ionicons/icons';
import { UsuarioModel } from 'src/app/model/usuario.model';
import { UsuarioService } from 'src/app/services/usuario.service';
import { ToastController } from '@ionic/angular';
import { NavController } from '@ionic/angular';
import { LoginService } from 'src/app/services/login.service';
import { TokenService } from 'src/app/services/token.service';
import { finalize, map, of, switchMap } from 'rxjs';
import { mostrarAviso } from 'src/app/utils/aviso.util';

@Component({
  selector: 'app-usuario',
  templateUrl: './usuario.page.html',
  styleUrls: ['./usuario.page.scss'],
  standalone: true,
  imports: [
    IonContent, IonHeader, IonTitle, IonToolbar,
    IonButtons, IonBackButton, IonItem, IonInput,
    IonButton, IonIcon,
    CommonModule, ReactiveFormsModule,
  ],
})
export class UsuarioPage implements OnInit {

  formGroup: FormGroup;
  usuario: UsuarioModel = new UsuarioModel();
  usuarioOriginal: { nome: string; email: string; foto: string } = { nome: '', email: '', foto: '' };
  private imagemSelecionada: File | null = null;
  private imagemBase64Selecionada: string | null = null;
  private previewUrl: string | null = null;
  processandoFoto = false;
  salvando = false;

  mostrarSenhaAtual = false;
  mostrarNovaSenha = false;
  mostrarConfirmar = false;

  get iniciais(): string {
    const nome = this.formGroup.get('nome')?.value || '';
    return nome
      .split(' ')
      .map((p: string) => p[0]?.toUpperCase() ?? '')
      .slice(0, 2)
      .join('');
  }

  get senhasDiferentes(): boolean {
    const nova = this.formGroup.get('novaSenha')?.value || '';
    const confirmar = this.formGroup.get('confirmarSenha')?.value || '';

    if (!nova && !confirmar) {
      return false;
    }

    return nova !== confirmar;
  }

  /** Trocar o e-mail ou a senha exige confirmar a senha atual (a API confere). */
  get trocandoCredenciais(): boolean {
    const novaPreenchida = !!this.formGroup.get('novaSenha')?.value;
    const email: string = this.formGroup.get('email')?.value || '';
    return novaPreenchida || email.trim().toLowerCase() !== (this.usuarioOriginal.email || '').toLowerCase();
  }

  get senhaAtualObrigatoria(): boolean {
    const senhaAtualPreenchida = !!this.formGroup.get('senhaAtual')?.value;
    return this.trocandoCredenciais && !senhaAtualPreenchida;
  }

  /** Mesmo mínimo do cadastro: 8 caracteres. */
  get novaSenhaCurta(): boolean {
    const novaSenha: string = this.formGroup.get('novaSenha')?.value || '';
    return novaSenha.length > 0 && novaSenha.length < 8;
  }

  /** O campo tem erro e o usuário já mexeu nele. */
  campoInvalido(campo: string): boolean {
    const controle = this.formGroup.get(campo);
    return !!controle && controle.invalid && (controle.touched || controle.dirty);
  }

  constructor(
    private formBuilder: FormBuilder,
    private usuarioService: UsuarioService,
    private toastController: ToastController,
    private navController: NavController,
    private loginService: LoginService,
    private tokenService: TokenService
  ) {
    addIcons({ eyeOutline, eyeOffOutline });

    this.formGroup = this.formBuilder.group({
      nome: ['', Validators.required],
      email: ['', [Validators.required, Validators.email]],
      senhaAtual: [''],
      novaSenha: [''],
      confirmarSenha: [''],
    });
  }

  get semAlteracoes(): boolean {
    const { nome, email, novaSenha, confirmarSenha } = this.formGroup.value;

    const nomeIgual = nome === this.usuarioOriginal.nome;
    const emailIgual = email === this.usuarioOriginal.email;
    const fotoIgual = (this.usuario.foto || '') === this.usuarioOriginal.foto;
    const semSenha = !novaSenha && !confirmarSenha;

    return nomeIgual && emailIgual && fotoIgual && semSenha;
  }

  ngOnInit() {
    this.usuario = this.usuarioService.buscarAutenticacao();

    this.usuarioOriginal = {
      nome: this.usuario.nome,
      email: this.usuario.email,
      foto: this.usuario.foto || '',
    };

    this.formGroup.patchValue({
      nome: this.usuario.nome,
      email: this.usuario.email,
    });
  }

  async selecionarFoto(evento: Event): Promise<void> {
    const input = evento.target as HTMLInputElement;
    const arquivo = input.files?.[0];
    input.value = '';

    if (!arquivo) return;
    if (!arquivo.type.startsWith('image/')) {
      await this.exibirToast('Escolha um arquivo de imagem.');
      return;
    }
    if (arquivo.size > 5 * 1024 * 1024) {
      await this.exibirToast('Escolha uma imagem de no máximo 5 MB.');
      return;
    }

    this.processandoFoto = true;
    try {
      const dataUri = await this.lerComoDataUri(arquivo);
      if (this.previewUrl) URL.revokeObjectURL(this.previewUrl);
      this.previewUrl = URL.createObjectURL(arquivo);
      this.imagemSelecionada = arquivo;
      this.imagemBase64Selecionada = dataUri;
      this.usuario.foto = this.previewUrl;
    } catch {
      await this.exibirToast('Não foi possível preparar essa imagem. Tente outra foto.');
    } finally {
      this.processandoFoto = false;
    }
  }

  private lerComoDataUri(arquivo: File): Promise<string> {
    return new Promise((resolve, reject) => {
      const leitor = new FileReader();
      leitor.onload = () => resolve(leitor.result as string);
      leitor.onerror = () => reject(leitor.error);
      leitor.readAsDataURL(arquivo);
    });
  }

  removerFoto(): void {
    if (this.previewUrl) URL.revokeObjectURL(this.previewUrl);
    this.previewUrl = null;
    this.imagemSelecionada = null;
    this.imagemBase64Selecionada = null;
    this.usuario.foto = '';
  }

  private exibirToast(mensagem: string, _cor: 'success' | 'danger' = 'danger'): void {
    mostrarAviso(mensagem, 3000);
  }

  salvar() {
    if (this.salvando || !this.formGroup.valid || this.senhasDiferentes) return;

    if (!this.tokenService.estaValido()) {
      this.loginService.encerrarAutenticacao();
      this.exibirToast('Sua sessão expirou. Entre novamente para salvar o perfil.');
      this.navController.navigateRoot('/login');
      return;
    }

    const idUsuarioAutenticado = this.tokenService.extrair().id;
    if (!idUsuarioAutenticado) {
      this.loginService.encerrarAutenticacao();
      this.exibirToast('Sua sessão não foi identificada. Entre novamente para salvar o perfil.');
      this.navController.navigateRoot('/login');
      return;
    }

    this.usuario.id = idUsuarioAutenticado;

    this.salvando = true;

    const { nome, email, senhaAtual, novaSenha } = this.formGroup.value;

    const atualizar = () => {
      this.usuario.nome = nome;
      this.usuario.email = email;
      this.usuario.senha = novaSenha || null as any;

      if (novaSenha) {
        this.usuario.senha = novaSenha;
      }

      const trocouCredenciais = this.trocandoCredenciais;
      this.usuario.senhaAtual = trocouCredenciais ? senhaAtual : undefined;

      // com e-mail ou senha novos, a API invalida os tokens antigos (inclusive o deste aparelho),
      // ent entra de novo com os dados novos pra continuar logado
      const salvarDadosUsuario = () => this.usuarioService.salvar(this.usuario).pipe(
        switchMap(usuarioAtualizado => trocouCredenciais
          ? this.loginService.autenticar({ email, senha: novaSenha || senhaAtual }).pipe(map(() => usuarioAtualizado))
          : of(usuarioAtualizado))
      );

      // a foto só muda pelas rotas próprias: upload da nova ou remoção da atual
      const removeuFoto = !this.imagemBase64Selecionada && !!this.usuarioOriginal.foto && !this.usuario.foto;
      const atualizarFoto = this.imagemBase64Selecionada
        ? this.usuarioService.atualizarImagem(this.imagemBase64Selecionada)
        : removeuFoto
          ? this.usuarioService.removerFoto()
          : null;

      (atualizarFoto
        ? atualizarFoto.pipe(
          switchMap(resposta => {
            this.usuario.foto = resposta.foto;
            return salvarDadosUsuario();
          })
        )
        : salvarDadosUsuario()
      ).pipe(finalize(() => {
        this.imagemSelecionada = null;
        this.imagemBase64Selecionada = null;
        this.salvando = false;
      }))
        .subscribe({
          next: (usuarioAtualizado) => {
            this.usuario = usuarioAtualizado;
            this.loginService.registrarAutenticacao(usuarioAtualizado);
            this.navController.navigateForward('/tabs/perfil');
          },
          error: (erro) => {
            console.error('[SchoolSync] Falha ao salvar perfil/foto - status:', erro?.status, 'corpo:', erro?.error);
            if (erro?.status === 401 || erro?.status === 403) {
              this.loginService.encerrarAutenticacao();
              this.exibirToast('Sua sessão não foi aceita pelo servidor. Entre novamente e tente salvar a foto.');
              this.navController.navigateRoot('/login');
              return;
            }
            const mensagem = erro?.error?.message || 'Erro ao atualizar usuário.';
            this.exibirToast(mensagem);
          }
        });
    };

    // a senha atual é conferida pela própria API (antes era só aqui no app)
    atualizar();
  }
}
