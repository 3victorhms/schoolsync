import { Component, OnInit } from '@angular/core';
import { ProgressoTarefasComponent } from 'src/app/components/progresso-tarefas/progresso-tarefas.component';
import { CommonModule } from '@angular/common';
import { RouterLink, ActivatedRoute } from '@angular/router';
import {
  IonContent,
  IonHeader,
  IonToolbar,
  IonTitle,
  IonButtons,
  IonBackButton,
  IonIcon,
  IonRefresher,
  IonRefresherContent,
  IonSpinner,
  IonTabBar,
  IonTabButton,
  IonLabel
} from '@ionic/angular/standalone';
import { addIcons } from 'ionicons';
import {
  addOutline,
  personAddOutline,
  peopleOutline,
  chevronForwardOutline,
  homeOutline,
  bookOutline,
  personOutline
} from 'ionicons/icons';
import { GrupoModel } from 'src/app/model/grupo.model';
import { UsuarioModel } from 'src/app/model/usuario.model';
import { GrupoService } from 'src/app/services/grupo.service';
import { UsuarioService } from 'src/app/services/usuario.service';
import { finalize } from 'rxjs';

@Component({
  selector: 'app-grupos',
  templateUrl: './grupos.page.html',
  styleUrls: ['./grupos.page.scss'],
  standalone: true,
  imports: [
    ProgressoTarefasComponent,
    IonContent,
    IonHeader,
    IonToolbar,
    IonTitle,
    IonButtons,
    IonBackButton,
    IonIcon,
    IonRefresher,
    IonRefresherContent,
    IonSpinner,
    IonTabBar,
    IonTabButton,
    IonLabel,
    CommonModule,
    RouterLink
  ]
})
export class GruposPage implements OnInit {

  idSala: string;
  usuario: UsuarioModel;
  grupos: GrupoModel[];
  carregando = true;

  constructor(
    private activatedRoute: ActivatedRoute,
    private grupoService: GrupoService,
    private usuarioService: UsuarioService
  ) {
    this.idSala = '';
    this.usuario = this.usuarioService.buscarAutenticacao();
    this.grupos = [];

    addIcons({
      addOutline,
      personAddOutline,
      peopleOutline,
      chevronForwardOutline,
      homeOutline,
      bookOutline,
      personOutline
    });
  }

  ngOnInit() { }

  ionViewWillEnter() {
    this.idSala = this.activatedRoute.snapshot.params['idSala'];
    this.usuario = this.usuarioService.buscarAutenticacao();
    this.carregarGrupos();
  }

  carregarGrupos(event?: any) {
    if (!this.idSala || !this.usuario.id) {
      this.grupos = [];
      this.carregando = false;
      event?.target.complete();
      return;
    }

    this.grupoService.listarMeusGruposDaSala(this.idSala).pipe(
      finalize(() => {
        this.carregando = false;
        event?.target.complete();
      })
    ).subscribe({
      next: (res) => {
        this.grupos = res;
      },
      error: () => {
        this.grupos = [];
      }
    });
  }

  atualizar(event: any) {
    this.carregarGrupos(event);
  }
}
